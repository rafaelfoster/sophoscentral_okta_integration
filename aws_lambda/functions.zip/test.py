#!/usr/bin/python

from main import *

main()
